const express = require("express");

const app = express();
app.use(express.json());

const names = [
  "Tenzin Dorji",
  "Karma Wangmo",
  "Pema Choden",
  "Sonam Tshering",
  "Dechen Lhamo",
  "Jigme Norbu",
  "Kinley Zangmo",
  "Ugyen Tobgay",
  "Choki Dema",
  "Dorji Wangchuk",
  "Yeshey Pelden",
  "Tashi Namgay",
  "Sangay Lham",
  "Nima Gyeltshen",
  "Chimi Rinzin",
  "Lhaki Yangden",
  "Thinley Penjor",
  "Rinchen Zam",
  "Namgay Dukpa",
  "Phuntsho Eden"
];

const courses = [
  "Software Engineering",
  "Computer Science",
  "Information Technology",
  "Data Science"
];

function buildSeed() {
  return names.map((name, index) => ({
    id: index + 1,
    name: name,
    email: "student" + (index + 1) + "@example.com",
    course: courses[index % courses.length]
  }));
}

let students = buildSeed();
let nextId = students.length + 1;

app.get("/students", (req, res) => {
  const name = req.query.name;
  if (name) {
    const matches = students.filter((s) =>
      s.name.toLowerCase().includes(String(name).toLowerCase())
    );
    return res.json(matches);
  }
  res.json(students);
});

app.get("/students/:id", (req, res) => {
  const id = parseInt(req.params.id, 10);
  const student = students.find((s) => s.id === id);
  if (!student) {
    return res.status(404).json({ error: "Student not found" });
  }
  res.json(student);
});

app.post("/students", (req, res) => {
  const { name, email, course } = req.body || {};
  if (!name || !email || !course) {
    return res
      .status(400)
      .json({ error: "name, email and course are required" });
  }
  if (students.some((s) => s.email === email)) {
    return res.status(409).json({ error: "Email already exists" });
  }
  const student = { id: nextId, name: name, email: email, course: course };
  nextId += 1;
  students.push(student);
  res.status(201).json(student);
});

app.put("/students/:id", (req, res) => {
  const id = parseInt(req.params.id, 10);
  const student = students.find((s) => s.id === id);
  if (!student) {
    return res.status(404).json({ error: "Student not found" });
  }
  const { name, email, course } = req.body || {};
  if (name) student.name = name;
  if (email) student.email = email;
  if (course) student.course = course;
  res.json(student);
});

app.delete("/students/:id", (req, res) => {
  const id = parseInt(req.params.id, 10);
  const index = students.findIndex((s) => s.id === id);
  if (index === -1) {
    return res.status(404).json({ error: "Student not found" });
  }
  students.splice(index, 1);
  res.json({ message: "Student deleted" });
});

app.post("/reset", (req, res) => {
  students = buildSeed();
  nextId = students.length + 1;
  res.json({ message: "Data restored", count: students.length });
});

app.get("/reports/slow", (req, res) => {
  let delay = parseInt(req.query.delay, 10);
  if (isNaN(delay) || delay < 0) delay = 500;
  if (delay > 5000) delay = 5000;
  setTimeout(() => {
    res.json({ totalStudents: students.length, delayMs: delay });
  }, delay);
});

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log("Student API running on http://localhost:" + port);
});
