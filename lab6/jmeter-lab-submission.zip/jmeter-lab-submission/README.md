# Student API JMeter Performance Test (SWE302 Lab Practical 6)

## 1. Contents

    performance_test.jmx    JMeter test plan
    data/students.csv       Dummy CSV data (12 rows: searchTerm, studentName, course)
    results/                One .jtl result file and one resource log per run
    reports/                One generated HTML report folder per run (open index.html)
    app/                    Source of the test application (Node.js and Express)

The folder results/warmup.jtl comes from a short warm-up run (2 users, 15 seconds). It is not part of the measured results.

## 2. Requirements

- Java 17 (JMeter 5.6.3 needs Java 8 or later)
- Apache JMeter 5.6.3
- Node.js 22 and npm

## 3. Start the application

    cd app
    npm install
    npm start

The application runs at http://localhost:3000 and keeps all data in memory. Keep this terminal open while testing.

Endpoints:

    GET    /students              list students
    GET    /students?name=Tenzin  search students by name
    GET    /students/:id          view one student
    POST   /students              add a student (JSON: name, email, course)
    PUT    /students/:id          update a student
    DELETE /students/:id          delete a student
    POST   /reset                 restore the original 20 students
    GET    /reports/slow?delay=500  slow report with an artificial delay in ms

## 4. Prepare and restore data

Run this before every run so each run starts from the same state:

    curl -X POST http://localhost:3000/reset

## 5. Reproduce the runs

Open a second terminal in this folder. Replace JMETER_BIN with the path to the JMeter bin folder, for example ~/jmeter-lab/tools/apache-jmeter-5.6.3/bin

The plan reads these properties (defaults in brackets): users (5), rampup (5), duration (65), thinkTime (1000, in milliseconds).

For each run, reset the data first, then start CPU and memory logging, then run JMeter:

    curl -X POST http://localhost:3000/reset
    top -l 75 -s 1 -n 10 -o cpu -stats pid,command,cpu,mem > results/NAME_resources.txt &
    JMETER_BIN/jmeter -n -t performance_test.jmx -l results/NAME.jtl -Jusers=N -Jrampup=R -Jduration=D -e -o reports/NAME

Use these values:

    NAME             N    R    D    other
    baseline_run1    5    5    65
    baseline_run2    5    5    65
    moderate_run1    20   10   70
    moderate_run2    20   10   70
    higher_run1      50   20   80
    higher_run2      50   20   80
    thinktime500     20   10   70   add -JthinkTime=500

Use top -l 80 for the moderate runs and the think time run, and top -l 90 for the higher runs.

Each NAME needs a new .jtl file and a reports/NAME folder that does not exist or is empty. Delete the old ones before repeating a run, or choose a new NAME.

Warm-up run used before the measured runs:

    JMETER_BIN/jmeter -n -t performance_test.jmx -l results/warmup.jtl -Jusers=2 -Jrampup=2 -Jduration=15

## 6. Notes

- The plan has a Thread Group with infinite loops and a thread lifetime. The duration is the ramp-up plus 60 seconds of steady load.
- View Results Tree, Summary Report and Assertion Results are disabled for load runs. To use them in the JMeter GUI, right-click each one and choose Enable.
- The application has no login, so no cookie or token handling is used. The workflow depends on the student ID extracted from the Add Student response.
- Think time is an artificial delay set by the Constant Timer.
- Statistics include the ramp-up period for every run.
- The Total row in each report counts individual requests only. The Student Workflow Transaction row is reported separately.
